import 'dart:async';
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_v2ray_client/flutter_v2ray_client.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import '../models/server_model.dart';
import '../models/theme_model.dart';

// ─── VPN State ────────────────────────────────────────────────────────────────

enum VpnStatus { disconnected, connecting, connected }

class VpnState {
  final VpnStatus status;
  final int rxBytes;
  final int txBytes;
  final int rxSpeed;
  final int txSpeed;
  final String duration;

  const VpnState({
    this.status = VpnStatus.disconnected,
    this.rxBytes = 0,
    this.txBytes = 0,
    this.rxSpeed = 0,
    this.txSpeed = 0,
    this.duration = '00:00:00',
  });

  VpnState copyWith({
    VpnStatus? status,
    int? rxBytes,
    int? txBytes,
    int? rxSpeed,
    int? txSpeed,
    String? duration,
  }) {
    return VpnState(
      status: status ?? this.status,
      rxBytes: rxBytes ?? this.rxBytes,
      txBytes: txBytes ?? this.txBytes,
      rxSpeed: rxSpeed ?? this.rxSpeed,
      txSpeed: txSpeed ?? this.txSpeed,
      duration: duration ?? this.duration,
    );
  }
}

// ─── Prefs keys ───────────────────────────────────────────────────────────────

const _kTheme = 'ingnet_theme';
const _kActiveServer = 'ingnet_active_server';
const _kTimeoutMs = 'ingnet_timeout_ms';
const _kTestUrl = 'ingnet_test_url';
const _kAutoMode = 'ingnet_auto_mode';
const _kAutoInterval = 'ingnet_auto_interval';
const _kAutoDepth = 'ingnet_auto_depth';
const _kSuppressRu = 'ingnet_suppress_russia_warning';
const _kFirstConnect = 'ingnet_first_connect';
const _kServersCache = 'ingnet_servers_cache';
const _kNotificationMode = 'ingnet_notification_mode';

// ─── Settings State ───────────────────────────────────────────────────────────

class SettingsState {
  final String themeId;
  final int activeServerIndex;
  final int timeoutMs;
  final String testUrl;
  final bool autoMode;
  final int autoIntervalMin;
  final String autoDepth;
  final bool suppressRuWarning;
  final bool firstConnectDone;
  final String notificationMode;

  const SettingsState({
    this.themeId = 'adrenalin',
    this.activeServerIndex = 0,
    this.timeoutMs = 10000,
    this.testUrl = 'https://www.google.com',
    this.autoMode = false,
    this.autoIntervalMin = 30,
    this.autoDepth = 'FIRST_GOOD',
    this.suppressRuWarning = false,
    this.firstConnectDone = false,
    this.notificationMode = 'all',
  });

  SettingsState copyWith({
    String? themeId,
    int? activeServerIndex,
    int? timeoutMs,
    String? testUrl,
    bool? autoMode,
    int? autoIntervalMin,
    String? autoDepth,
    bool? suppressRuWarning,
    bool? firstConnectDone,
    String? notificationMode,
  }) {
    return SettingsState(
      themeId: themeId ?? this.themeId,
      activeServerIndex: activeServerIndex ?? this.activeServerIndex,
      timeoutMs: timeoutMs ?? this.timeoutMs,
      testUrl: testUrl ?? this.testUrl,
      autoMode: autoMode ?? this.autoMode,
      autoIntervalMin: autoIntervalMin ?? this.autoIntervalMin,
      autoDepth: autoDepth ?? this.autoDepth,
      suppressRuWarning: suppressRuWarning ?? this.suppressRuWarning,
      firstConnectDone: firstConnectDone ?? this.firstConnectDone,
      notificationMode: notificationMode ?? this.notificationMode,
    );
  }

  AppTheme get theme {
    return THEMES.firstWhere(
      (t) => t.id == themeId,
      orElse: () => THEMES.first,
    );
  }
}

// ─── Servers Notifier ─────────────────────────────────────────────────────────

class ServersNotifier extends StateNotifier<List<VpnServer>> {
  ServersNotifier() : super([]) {
    _loadServers();
  }

  Future<void> _loadServers() async {
    final prefs = await SharedPreferences.getInstance();
    final cached = prefs.getString(_kServersCache);
    if (cached != null) {
      try {
        final list = (jsonDecode(cached) as List)
            .map((e) => VpnServer.fromJson(e as Map<String, dynamic>))
            .toList();
        if (list.isNotEmpty) {
          state = list;
          return;
        }
      } catch (_) {}
    }
    await fetchServers();
  }

  Future<void> fetchServers() async {
    try {
      final response = await http
          .get(Uri.parse(
              'https://raw.githubusercontent.com/INGNET06/INGNET/refs/heads/main/INGNETVPN.txt'))
          .timeout(const Duration(seconds: 15));

      if (response.statusCode == 200) {
        final lines = response.body
            .split('\n')
            .map((l) => l.trim())
            .where((l) => l.isNotEmpty)
            .toList();

        final servers = <VpnServer>[];
        for (final line in lines) {
          final server = _parseLine(line);
          if (server != null) servers.add(server);
        }

        if (servers.isNotEmpty) {
          state = servers;
          final prefs = await SharedPreferences.getInstance();
          await prefs.setString(
            _kServersCache,
            jsonEncode(servers.map((s) => s.toJson()).toList()),
          );
          return;
        }
      }
    } catch (e) {
      debugPrint('Error fetching servers: $e');
    }

    // Fallback
    if (state.isEmpty) {
      state = FALLBACK_SERVERS
          .map((s) => VpnServer(name: s['name']!, config: s['config']!))
          .toList();
    }
  }

  VpnServer? _parseLine(String line) {
    try {
      final hashIdx = line.lastIndexOf('#');
      if (hashIdx < 0) return null;
      final rawName = line.substring(hashIdx + 1);
      String name;
      try {
        name = Uri.decodeComponent(rawName.replaceAll('+', ' '));
      } catch (_) {
        name = rawName;
      }
      if (name.isEmpty) name = 'Server';
      return VpnServer(name: name, config: line);
    } catch (_) {
      return null;
    }
  }

  Future<void> updateServerPing(int index, int? ping) async {
    if (index < 0 || index >= state.length) return;
    final updated = List<VpnServer>.from(state);
    updated[index] = updated[index].copyWith(ping: ping);
    state = updated;
  }

  Future<void> setServerTesting(int index, bool testing) async {
    if (index < 0 || index >= state.length) return;
    final updated = List<VpnServer>.from(state);
    updated[index] = updated[index].copyWith(isTesting: testing);
    state = updated;
  }

  void sortByPing() {
    final sorted = List<VpnServer>.from(state);
    sorted.sort((a, b) {
      if (a.ping == null && b.ping == null) return 0;
      if (a.ping == null) return 1;
      if (b.ping == null) return -1;
      return a.ping!.compareTo(b.ping!);
    });
    state = sorted;
  }
}

// ─── Settings Notifier ────────────────────────────────────────────────────────

class SettingsNotifier extends StateNotifier<SettingsState> {
  SettingsNotifier() : super(const SettingsState()) {
    _loadSettings();
  }

  Future<void> _loadSettings() async {
    final prefs = await SharedPreferences.getInstance();
    state = SettingsState(
      themeId: prefs.getString(_kTheme) ?? 'adrenalin',
      activeServerIndex: prefs.getInt(_kActiveServer) ?? 0,
      timeoutMs: prefs.getInt(_kTimeoutMs) ?? 10000,
      testUrl: prefs.getString(_kTestUrl) ?? 'https://www.google.com',
      autoMode: prefs.getBool(_kAutoMode) ?? false,
      autoIntervalMin: prefs.getInt(_kAutoInterval) ?? 30,
      autoDepth: prefs.getString(_kAutoDepth) ?? 'FIRST_GOOD',
      suppressRuWarning: prefs.getBool(_kSuppressRu) ?? false,
      firstConnectDone: prefs.getBool(_kFirstConnect) ?? false,
      notificationMode: prefs.getString(_kNotificationMode) ?? 'all',
    );
  }

  Future<void> setTheme(String themeId) async {
    state = state.copyWith(themeId: themeId);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_kTheme, themeId);
  }

  Future<void> setActiveServer(int index) async {
    state = state.copyWith(activeServerIndex: index);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(_kActiveServer, index);
  }

  Future<void> setTimeoutMs(int ms) async {
    state = state.copyWith(timeoutMs: ms);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(_kTimeoutMs, ms);
  }

  Future<void> setTestUrl(String url) async {
    state = state.copyWith(testUrl: url);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_kTestUrl, url);
  }

  Future<void> setAutoMode(bool v) async {
    state = state.copyWith(autoMode: v);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_kAutoMode, v);
  }

  Future<void> setAutoInterval(int min) async {
    state = state.copyWith(autoIntervalMin: min);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(_kAutoInterval, min);
  }

  Future<void> setAutoDepth(String depth) async {
    state = state.copyWith(autoDepth: depth);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_kAutoDepth, depth);
  }

  Future<void> setSuppressRuWarning(bool v) async {
    state = state.copyWith(suppressRuWarning: v);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_kSuppressRu, v);
  }

  Future<void> markFirstConnectDone() async {
    state = state.copyWith(firstConnectDone: true);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_kFirstConnect, true);
  }

  Future<void> setNotificationMode(String mode) async {
    state = state.copyWith(notificationMode: mode);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_kNotificationMode, mode);
  }
}

// ─── VPN Notifier ─────────────────────────────────────────────────────────────

class VpnNotifier extends StateNotifier<VpnState> {
  VpnNotifier() : super(const VpnState()) {
    _init();
  }

  late final FlutterV2ray _v2ray;
  int _prevRx = 0;
  int _prevTx = 0;
  DateTime? _prevTime;
  int _accRx = 0;
  int _accTx = 0;
  bool _initialized = false;

  void _init() {
    _v2ray = FlutterV2ray(
      onStatusChanged: _handleStatus,
    );
    _v2ray.initializeV2Ray(
      notificationIconResourceType: 'mipmap',
      notificationIconResourceName: 'ic_launcher',
    );
    _initialized = true;
  }

  void _handleStatus(V2RayStatus s) {
    final connected = s.state == 'CONNECTED';
    final connecting = s.state == 'CONNECTING';
    final now = DateTime.now();

    if (connected) {
      final rx = s.download ?? 0;
      final tx = s.upload ?? 0;
      int rxSpeed = 0;
      int txSpeed = 0;
      if (_prevTime != null) {
        final elapsed =
            now.difference(_prevTime!).inMilliseconds / 1000.0;
        if (elapsed > 0) {
          rxSpeed = ((rx - _prevRx) / elapsed).round().clamp(0, 999999999);
          txSpeed = ((tx - _prevTx) / elapsed).round().clamp(0, 999999999);
        }
      }
      _prevRx = rx;
      _prevTx = tx;
      _prevTime = now;
      state = state.copyWith(
        status: VpnStatus.connected,
        rxBytes: _accRx + rx,
        txBytes: _accTx + tx,
        rxSpeed: rxSpeed,
        txSpeed: txSpeed,
        duration: s.duration ?? '00:00:00',
      );
    } else if (connecting) {
      state = state.copyWith(status: VpnStatus.connecting);
    } else {
      _accRx = state.rxBytes;
      _accTx = state.txBytes;
      _prevRx = 0;
      _prevTx = 0;
      _prevTime = null;
      state = state.copyWith(
        status: VpnStatus.disconnected,
        rxSpeed: 0,
        txSpeed: 0,
        duration: '00:00:00',
      );
    }
  }

  Future<bool> requestPermission() async {
    return await _v2ray.requestVpnPermission();
  }

  Future<void> startVpn({
    required String remark,
    required String config,
    required String notificationMode,
  }) async {
    state = state.copyWith(status: VpnStatus.connecting);
    try {
      await _v2ray.startV2Ray(
        remark: remark,
        config: config,
        proxyOnly: false,
        notificationDisconnectButtonName:
            notificationMode == 'speed_only' ? null : 'Отключить VPN',
        showNotification: notificationMode != 'hidden',
      );
    } catch (e) {
      debugPrint('VPN start error: $e');
      state = state.copyWith(status: VpnStatus.disconnected);
    }
  }

  Future<void> stopVpn() async {
    await _v2ray.stopV2Ray();
    state = state.copyWith(status: VpnStatus.disconnected);
  }

  Future<int?> getServerDelay(String config, String testUrl) async {
    try {
      final delay = await _v2ray.getServerDelay(config: config, url: testUrl);
      return delay;
    } catch (_) {
      return null;
    }
  }

  void resetTraffic() {
    _accRx = 0;
    _accTx = 0;
    _prevRx = 0;
    _prevTx = 0;
    state = state.copyWith(rxBytes: 0, txBytes: 0);
  }
}

// ─── Providers ────────────────────────────────────────────────────────────────

final serversProvider =
    StateNotifierProvider<ServersNotifier, List<VpnServer>>(
  (ref) => ServersNotifier(),
);

final settingsProvider =
    StateNotifierProvider<SettingsNotifier, SettingsState>(
  (ref) => SettingsNotifier(),
);

final vpnProvider = StateNotifierProvider<VpnNotifier, VpnState>(
  (ref) => VpnNotifier(),
);
