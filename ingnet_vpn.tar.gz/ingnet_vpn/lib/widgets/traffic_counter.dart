import 'package:flutter/material.dart';
import '../core/vpn_provider.dart';
import '../models/theme_model.dart';
import '../utils/format_bytes.dart';

class TrafficCounter extends StatelessWidget {
  final VpnState vpnState;
  final AppTheme theme;
  final VoidCallback onReset;

  const TrafficCounter({
    super.key,
    required this.vpnState,
    required this.theme,
    required this.onReset,
  });

  @override
  Widget build(BuildContext context) {
    final primary = theme.primary;
    final bg = theme.surface;
    final isConnected = vpnState.status == VpnStatus.connected;

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: primary.withOpacity(0.3)),
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _StatCell(
                icon: Icons.arrow_downward,
                label: 'Получено',
                value: formatBytes(vpnState.rxBytes),
                speed: isConnected ? '↓ ${formatSpeed(vpnState.rxSpeed)}' : null,
                color: primary,
                theme: theme,
              ),
              Container(width: 1, height: 50, color: primary.withOpacity(0.2)),
              _StatCell(
                icon: Icons.arrow_upward,
                label: 'Отправлено',
                value: formatBytes(vpnState.txBytes),
                speed: isConnected ? '↑ ${formatSpeed(vpnState.txSpeed)}' : null,
                color: primary,
                theme: theme,
              ),
              if (isConnected) ...[
                Container(
                    width: 1, height: 50, color: primary.withOpacity(0.2)),
                _StatCell(
                  icon: Icons.timer,
                  label: 'Время',
                  value: vpnState.duration,
                  color: primary,
                  theme: theme,
                ),
              ],
            ],
          ),
          const SizedBox(height: 8),
          GestureDetector(
            onTap: onReset,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
              decoration: BoxDecoration(
                border: Border.all(color: primary.withOpacity(0.4)),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Text(
                'Сброс трафика',
                style: TextStyle(
                  color: primary.withOpacity(0.7),
                  fontSize: 11,
                  fontFamily: theme.fontFamily,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _StatCell extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  final String? speed;
  final Color color;
  final AppTheme theme;

  const _StatCell({
    required this.icon,
    required this.label,
    required this.value,
    this.speed,
    required this.color,
    required this.theme,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Icon(icon, color: color, size: 18),
        const SizedBox(height: 2),
        Text(
          label,
          style: TextStyle(
              color: color.withOpacity(0.6),
              fontSize: 9,
              fontFamily: theme.fontFamily),
        ),
        Text(
          value,
          style: TextStyle(
              color: color,
              fontSize: 12,
              fontWeight: FontWeight.bold,
              fontFamily: theme.fontFamily),
        ),
        if (speed != null)
          Text(
            speed!,
            style: TextStyle(
                color: color.withOpacity(0.8),
                fontSize: 10,
                fontFamily: theme.fontFamily),
          ),
      ],
    );
  }
}
