import 'package:flutter/material.dart';

class ScanlinesPainter extends CustomPainter {
  final Color color;
  final double spacing;

  ScanlinesPainter({
    this.color = const Color(0x0A00FF41),
    this.spacing = 4.0,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..strokeWidth = 1.0;

    for (double y = 0; y < size.height; y += spacing) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(ScanlinesPainter oldDelegate) =>
      oldDelegate.color != color || oldDelegate.spacing != spacing;
}
